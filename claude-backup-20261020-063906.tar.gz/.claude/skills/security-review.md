# security-review Skill

Complete a security review of the pending changes on the current branch