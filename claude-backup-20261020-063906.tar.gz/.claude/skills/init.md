# init Skill

Initialize a new CLAUDE.md file with codebase documentation