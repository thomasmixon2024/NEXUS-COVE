---
name: project-context
description: Load Nexus Cove project context — architecture, ADRs, common commands, and key files. Use at session start or when context is lost.
---

# Project Context Loader

## On Invocation
1. Read and summarize: CLAUDE.md (project instructions)
2. Read and summarize: docs/architecture/overview.md
3. List: docs/decisions/ADR-*.md (titles + one-line summaries)
4. Show: Common dev commands from CLAUDE.md
5. Show: Key entry points (manager, worker, server)
6. Show: Test commands and Definition of Done checklist

## Output Format
Concise briefing — what to work on, key constraints, how to run tests.