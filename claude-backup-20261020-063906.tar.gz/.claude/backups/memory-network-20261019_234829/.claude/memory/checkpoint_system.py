#!/usr/bin/env python3
"""
Checkpoint System for Claude Code Sessions
Generates and manages session checkpoints for continuity across conversations
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


class SessionCheckpoint:
    def __init__(self, session_dir: Path = None):
        if session_dir is None:
            session_dir = Path.cwd() / ".claude" / "memory"

        self.session_dir = session_dir
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_file = self.session_dir / "session_checkpoints.jsonl"
        self.current_checkpoint = self.session_dir / "current_checkpoint.json"

    def create_checkpoint(self, task_description: str, accomplishments: List[str],
                         next_steps: List[str] = None, metadata: Dict = None) -> str:
        """Create a new checkpoint entry"""

        checkpoint = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": os.getenv("CLAUDE_SESSION_ID", "unknown"),
            "task_description": task_description,
            "accomplishments": accomplishments,
            "next_steps": next_steps or [],
            "metadata": metadata or {},
            "checkpoint_id": self._generate_checkpoint_id()
        }

        # Append to journal
        with open(self.checkpoint_file, 'a') as f:
            f.write(json.dumps(checkpoint) + '\n')

        # Update current checkpoint
        with open(self.current_checkpoint, 'w') as f:
            json.dump(checkpoint, f, indent=2)

        return checkpoint["checkpoint_id"]

    def get_latest_checkpoint(self) -> Optional[Dict]:
        """Get the most recent checkpoint"""
        if not self.current_checkpoint.exists():
            return None

        try:
            with open(self.current_checkpoint, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return None

    def get_checkpoint_history(self, limit: int = 10) -> List[Dict]:
        """Get recent checkpoint history"""
        if not self.checkpoint_file.exists():
            return []

        checkpoints = []
        try:
            with open(self.checkpoint_file, 'r') as f:
                for line in f:
                    if line.strip():
                        checkpoints.append(json.loads(line))

            # Return most recent first
            return list(reversed(checkpoints))[:limit]
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def _generate_checkpoint_id(self) -> str:
        """Generate a unique checkpoint ID"""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return f"cp_{timestamp}"

    def print_session_continuity_guide(self):
        """Print guidance for continuing from last session"""
        latest = self.get_latest_checkpoint()
        if not latest:
            print("🆕 No previous session found - starting fresh")
            return

        print("\n" + "="*60)
        print("📋 SESSION CONTINUITY GUIDE")
        print("="*60)
        print(f"🕒 Last Session: {latest['timestamp']}")
        print(f"🎯 Task: {latest['task_description']}")
        print(f"✅ Accomplishments:")
        for acc in latest['accomplishments']:
            print(f"   • {acc}")
        print(f"🔜 Next Steps:")
        for step in latest['next_steps']:
            print(f"   • {step}")
        print("="*60)


def main():
    """CLI interface for checkpoint system"""
    import sys

    checkpoint = SessionCheckpoint()

    if len(sys.argv) > 1 and sys.argv[1] == "status":
        checkpoint.print_session_continuity_guide()
    elif len(sys.argv) > 1 and sys.argv[1] == "history":
        history = checkpoint.get_checkpoint_history(5)
        print("📜 Recent Checkpoint History:")
        for i, cp in enumerate(history, 1):
            print(f"{i}. [{cp['checkpoint_id']}] {cp['task_description']} ({cp['timestamp']})")
    else:
        print("Usage: checkpoint_system.py [status|history]")


if __name__ == "__main__":
    main()